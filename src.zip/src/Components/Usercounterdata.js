const Usercounterdata=[
    {
        number:"25000",
        menbers:"Members",
        des:"With 100% Satisfaction",
        image:"images/user-counter-image1.png",
    },
    {
        number:"35+",
        menbers:"Countries",
        des:"Covers around the World",
        image:"images/user-counter-image2.png",
    },
    {
        number:"467",
        menbers:"Cities",
        des:"Covers around the World",
        image:"images/user-counter-image3.png",
    },
    {
        number:"1890",
        menbers:"Workspaces",
        des:"With Essestial Amenities",
        image:"images/user-counter-image4.png",
    },
]

export default Usercounterdata;