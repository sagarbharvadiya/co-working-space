const Roompricedata=[
    {
        image:"images/room-price-image1.png",
        userplace:"FROM $500 / MO",
        title:"Office Space",
        usercount:"1",
        readmore:"Read More",
    },
    {
        image:"images/room-price-image1.png",
        userplace:"FROM $500 / MO",
        title:"Office Space",
        usercount:"1",
        readmore:"Read More",
    },
    {
        image:"images/room-price-image1.png",
        userplace:"FROM $500 / MO",
        title:"Office Space",
        usercount:"1",
        readmore:"Read More",
    },
    {
        image:"images/room-price-image1.png",
        userplace:"FROM $500 / MO",
        title:"Office Space",
        usercount:"1",
        readmore:"Read More",
    },

]

export default Roompricedata;