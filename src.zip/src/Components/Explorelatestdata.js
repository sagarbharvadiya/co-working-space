const Explorelatestdata=[
    {
        image1:"images/explore-latest-image1.jpg",
        image2:"images/explore-latest-image4.png",
        user:"By: Colmin O'Neill",
        text:"We've Officially Reached 15k Coworking Spaces!",
        des:"Laborious physical exercise excepts obtain some advantage from...",
        date:"20.08.2021",
    },
    {
        image1:"images/explore-latest-image2.jpg",
        image2:"images/explore-latest-image4.png",
        user:"By: Colmin O'Neill",
        text:"We've Officially Reached 15k Coworking Spaces!",
        des:"Laborious physical exercise excepts obtain some advantage from...",
        date:"20.08.2021",
    },
    {
        image1:"images/explore-latest-image3.jpg",
        image2:"images/explore-latest-image4.png",
        user:"By: Colmin O'Neill",
        text:"We've Officially Reached 15k Coworking Spaces!",
        des:"Laborious physical exercise excepts obtain some advantage from...",
        date:"20.08.2021",
    },
]

export default Explorelatestdata;