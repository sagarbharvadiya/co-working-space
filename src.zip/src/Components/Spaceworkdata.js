const Spacewraokdata=[
    {
        image:"images/space-work-image1.png",
        weoffer:"WE OFFER",
        title:"Exclusive Workspaces",
        des:"Trouble that are bound to ensue & equal fail in their duty...",
        ReadMore:"Read More",
    },
    {
        image:"images/space-work-image2.png",
        weoffer:"WE OFFER",
        title:"Shared Workspaces",
        des:"Every pleasure is too be welco- med every pain the avoided...",
        ReadMore:"Read More",
    },
    {
        image:"images/space-work-image3.png",
        weoffer:"WE OFFER",
        title:"Meetings & Events",
        des:"These cases are perfectly simple & easy to distinguish...",
        ReadMore:"Read More",
    },
]

export default Spacewraokdata;