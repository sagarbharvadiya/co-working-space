import React from 'react'
import Coworkingcitiessection from '../Components/Coworking-Cities-slider'
import Passioninspirationalsection from '../Components/Passion-Inspirational'

const About = () => {
  return (
    <>
    <Passioninspirationalsection/>
    <Coworkingcitiessection/>
    </>
  )
}

export default About