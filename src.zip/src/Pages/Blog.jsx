import React from 'react'
import Explorelatestblogsection from '../Components/Explore-Latest-Blog-section'

const Blog = () => {
  return (
    <>
    <Explorelatestblogsection/>
    </>
  )
}

export default Blog