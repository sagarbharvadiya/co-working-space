import React from 'react'

const Workspaces = () => {
  return (
    <>
    </>
  )
}

export default Workspaces