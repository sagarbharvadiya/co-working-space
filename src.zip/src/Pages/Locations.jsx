import React from 'react'
import GoogleMap from '../Components/Google_map'


const Locations = () => {
  return (
    <>
     <GoogleMap/>
    </>
  )
}

export default Locations