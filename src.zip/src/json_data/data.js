const Ourgallerydata=[
    {
        image1:"images/our-gallery-image1.jpg",
        image2:"images/our-gallery-image2.jpg",
        image3:"images/our-gallery-image3.jpg",
        image4:"images/our-gallery-image4.jpg",
        title1:"On-Site Management",
        title2:"On-Site Management",
        Details:"Details",
    },
    {
        image1:"images/our-gallery-image1.jpg",
        image2:"images/our-gallery-image2.jpg",
        image3:"images/our-gallery-image3.jpg",
        image4:"images/our-gallery-image4.jpg",
        title1:"On-Site Management",
        title2:"On-Site Management",
        Details:"Details",
        
    },
]

export default Ourgallerydata;